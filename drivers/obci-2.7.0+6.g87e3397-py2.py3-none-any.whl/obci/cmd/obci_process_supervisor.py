# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

from obci.control.launcher.obci_process_supervisor import run_obci_process_supervisor


def run():
    run_obci_process_supervisor()
