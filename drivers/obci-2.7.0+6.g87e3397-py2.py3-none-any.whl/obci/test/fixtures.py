# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

import os
import signal
import subprocess
import sys
from subprocess import TimeoutExpired

import pytest

from obci import utils
from obci.control.launcher.simple_obci_client import SimpleOBCIClient
from obci.core.broker import Broker
from obci.peers.acquisition.reusable_signal_saver_peer import ReusableSignalSaver
from obci.peers.control.config_server import ConfigServer
from obci.peers.drivers.amplifiers.random_amplifier_peer import RandomAmplifierPeer
from obci.test.tools import create_peer
from obci.utils import yield_then_shutdown, get_peer_config_file_path, is_windows


def pytest_configure(config):
    sys._called_from_test = True


def pytest_unconfigure(config):
    if hasattr(sys, '_called_from_test'):
        del sys._called_from_test


# https://docs.pytest.org/en/latest/example/simple.html#incremental-testing-test-steps
# Make test (in class marked as incremental) as xfail for each fixture id used
# Fixture used must be of scope='class' to work correctly
def pytest_runtest_makereport(item, call):
    if 'incremental' in item.keywords:
        parent = item.parent
        if not hasattr(parent, '_previousfailed'):
            parent._previousfailed = {}
        if call.excinfo is not None:
            parent._previousfailed[item._genid] = item


def pytest_runtest_setup(item):
    if 'incremental' in item.keywords:
        previousfailed = getattr(item.parent, '_previousfailed', {})
        if item._genid in previousfailed:
            pytest.xfail(
                'previous test failed ({})'.format(
                    previousfailed[item._genid].name
                )
            )


@pytest.fixture(scope='session')
def strings_list():
    yield [
        '', ' ', 'abc', '123', ' 123', ' abc ', ' 123 ',
        '\n', '\r', '\a', '\b', '\f', '\t', '\v', '\'', '\"', '`', '\\', '/', '', '\x00', 'a\x00b',
        'ą, ć, ę, ł, ń, ó, ś, ź, ż, Ą, Ć, Ę, Ł, Ń, Ó, Ś, Ź, Ż', '⛱',
        'Ё Ђ Ѓ Є Ѕ І Ї Ј Љ Њ Ћ Ќ Ў Џ А Б В Г Д Е Ж З И Й К Л М Н О П Р С Т У Ф Х Ц Ч'
        ' Ш Щ Ъ Ы Ь Э Ю Я а б в г д е ж з и й к л м н о п р с т у ф х ц ч ш щ ъ ы ь э ю я ё ђ'
        ' ѓ є ѕ і ї ј љ њ ћ ќ ў џ Ѡ ѡ Ѣ ѣ Ѥ ѥ Ѧ ѧ Ѩ ѩ Ѫ ѫ Ѭ ѭ Ѯ ѯ Ѱ ѱ Ѳ ѳ Ѵ ѵ Ѷ ѷ Ѹ ѹ Ѻ ѻ Ѽ ѽ'
        ' Ѿ ѿ Ҁ ҁ ҂ ҃ ...',
        '子曰：「學而時習之，不亦說乎？有朋自遠方來，不亦樂乎？人不知而不慍，不亦君子乎？」',
    ]


@pytest.fixture(scope='session')
def json_data(strings_list):
    dct = {
        'a': 1,
        'b': 2,
        'c': 'abc',
        'd': 1.5,
        'f': {
            'a': 10,
            'b': 11
        },
        'true': True,
        'false': False,
        'null': None,
        'array_1': [1, 2, 3, 4],
        'array_1a': ['1', '2', '3', '4'],
        'array_2': [1.5, 2.5, 3.5, 4.5],
        'array_3': [
            {'a': 'a'},
            {'b': 'b'}
        ],
        'array_3a': [
            {'a': 'a'},
            {'b': 'b'},
            {'c': [1, 2, [3, 4], 5]}
        ],
        'array_4': [1, 2, [3, 4], 5]
    }

    for idx, string in enumerate(strings_list, start=1):
        dct['unicode_{}'.format(idx)] = string

    yield dct


@pytest.fixture(scope='module')
def broker():
    yield from yield_then_shutdown(Broker())


@pytest.fixture(scope='module')
def config_server(broker):
    yield from yield_then_shutdown(
        ConfigServer(
            broker.broker_ip,
            peer_id='config_server',
            base_config_file=get_peer_config_file_path(ConfigServer),
        )
    )


@pytest.fixture()
def xfwm():
    if is_windows():
        return
    process = subprocess.Popen(['xfwm4'])
    yield
    try:
        process.kill()
    except ProcessLookupError:
        pass


@pytest.fixture()
def ffmpeg_testsrc():
    process = subprocess.Popen('ffmpeg -f lavfi -re -i testsrc=rate=10 -f v4l2 -framerate 10 /dev/video0 -loglevel 8'
                               .split())
    yield
    process.kill()


@pytest.fixture()
def svarog():
    process = subprocess.Popen('svarog')
    yield
    process.kill()


@pytest.fixture()
def simple_obci_server():
    server = subprocess.Popen("simple_obci_server")
    client = SimpleOBCIClient()
    client.ping_server(3000)
    yield client
    os.kill(server.pid, signal.SIGTERM)
    try:
        server.wait(10.0)
    except TimeoutExpired:
        server.kill()
        raise


@pytest.fixture(scope='module')
def amplifier(broker, config_server):
    config = {
        'local_params': {
            'autostart': '1',
            'autoshutdown': '0',
        },
    }
    peer = create_peer(RandomAmplifierPeer, broker, name='amplifier',
                       dependencies=[config_server], config=config)
    yield from utils.yield_then_shutdown(peer)


@pytest.fixture
def reusable_signal_saver(broker, config_server, amplifier):
    config = {
        'local_params': {
            'autostart': '0',
            'autoshutdown': '0',
            'debug_on': '0',
        },
        'launch_dependencies': {
            'signal_source': amplifier.id,
        }
    }
    peer = create_peer(ReusableSignalSaver, broker, name='reusable_signal_saver',
                       dependencies=[config_server, amplifier], config=config)
    yield from utils.yield_then_shutdown(peer)
