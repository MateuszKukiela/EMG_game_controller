# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.
from obci.conf import settings

CONFIG_DEFAULTS = {
    'log_dir': settings.log_dir,
    'reports_dir': '~/.obci/crash_reports',
    'experiment_uuid': ''
}
