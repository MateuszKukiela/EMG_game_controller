# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

import configparser
import json

import obci.control.common.config_helpers as helpers


class PeerConfigSerializer:
    config_parts = [
        helpers.CONFIG_SOURCES,
        helpers.LAUNCH_DEPENDENCIES,
        helpers.EXT_PARAMS,
        helpers.LOCAL_PARAMS
    ]

    def serialize(self, p_config, p_file_obj):
        self._prepare(p_config)
        self._do_serialize(p_config)
        self._save(p_file_obj)

    def serialize_diff(self, p_base_config, p_config, p_file_obj):
        self._prepare(p_config)
        self._do_serialize_diff(p_base_config, p_config)
        self._save(p_file_obj)

    def _prepare(self, p_config):
        raise NotImplementedError()

    def _save(self, p_file_obj):
        raise NotImplementedError()

    def _do_serialize(self, p_config):

        self._serialize_config_sources(p_config.config_sources)
        self._serialize_launch_deps(p_config.launch_deps)
        self._serialize_local_params(p_config.param_values,
                                     p_config.ext_param_defs)
        self._serialize_ext_params(p_config.param_values,
                                   p_config.ext_param_defs)

    def difference(self, p_base_config, p_config):
        sources = {}
        for src, val in p_config.config_sources.items():
            if src not in p_base_config.config_sources:
                sources[src] = val

        deps = {}
        for dep, val in p_config.launch_deps.items():
            if dep not in p_base_config.launch_deps:
                deps[dep] = val

        params = {}
        for par, val in p_config.param_values.items():
            if par not in p_base_config.param_values:
                params[par] = val
            elif val != p_base_config.param_values[par]:
                params[par] = val
        return sources, deps, params

    def _do_serialize_diff(self, p_base_config, p_config):
        sources, deps, params = self.difference(p_base_config, p_config)
        self._serialize_config_sources(sources)

        self._serialize_launch_deps(deps)

        self._serialize_local_params(params, p_config.ext_param_defs)
        self._serialize_ext_params(params, p_config.ext_param_defs)

    def _serialize_config_sources(self, p_sources):
        raise NotImplementedError()

    def _serialize_launch_deps(self, p_deps):
        raise NotImplementedError()

    def _serialize_ext_params(self, p_values, p_ext_param_defs):
        raise NotImplementedError()

    def _serialize_local_params(self, p_values, p_ext_param_defs):
        raise NotImplementedError()


class PeerConfigSerializerINI(PeerConfigSerializer):

    def __init__(self):
        self.parser = None

    def _prepare(self, p_config):
        self.parser = configparser.RawConfigParser()
        for sec in self.config_parts:
            self.parser.add_section(sec)

    def _save(self, p_file_obj):
        for sec in self.parser.sections():
            p_file_obj.write('\n[' + sec + ']\n')
            for opt in self.parser.options(sec):
                p_file_obj.write(opt + ' = ')
                p_file_obj.write(self.parser.get(sec, opt) + '\n')

    def _serialize_config_sources(self, p_sources):
        for src in p_sources.keys():
            self.parser.set(helpers.CONFIG_SOURCES, src, '')

    def _serialize_launch_deps(self, p_deps):
        for src in p_deps.keys():
            self.parser.set(helpers.LAUNCH_DEPENDENCIES, src, '')

    def _serialize_ext_params(self, p_values, p_ext_param_defs):
        for name, value in p_values.items():
            if name in p_ext_param_defs:
                (src, par) = p_ext_param_defs[name]
                val = src + '.' + par
                self.parser.set(helpers.EXT_PARAMS, name, val)

    def _serialize_local_params(self, p_values, p_ext_param_defs):
        for name, value in p_values.items():
            if name not in p_ext_param_defs:
                self.parser.set(helpers.LOCAL_PARAMS, name, value)


class PeerConfigSerializerJSON(PeerConfigSerializer):

    def __init__(self):
        self.dic = {}

    def _prepare(self, p_config):
        self.dic = {}

    def _save(self, p_file_obj):
        json.dump(self.dic, p_file_obj)

    def _do_serialize_diff(self, p_base_config, p_config):
        sources, deps, params = self.difference(p_base_config, p_config)
        self._serialize_config_sources(p_config.config_sources)

        self._serialize_launch_deps(p_config.launch_deps)

        self._serialize_local_params(params, p_config.ext_param_defs)
        self._serialize_ext_params(params, p_config.ext_param_defs)

    def _serialize_config_sources(self, p_sources):
        self.dic[helpers.CONFIG_SOURCES] = {}
        for name, value in p_sources.items():
            print('name, value', name, value)
            self.dic[helpers.CONFIG_SOURCES][name] = value

    def _serialize_launch_deps(self, p_deps):
        self.dic[helpers.LAUNCH_DEPENDENCIES] = {}
        for name, value in p_deps.items():
            self.dic[helpers.LAUNCH_DEPENDENCIES][name] = value

    def _serialize_local_params(self, p_values, p_ext_param_defs):
        self.dic[helpers.LOCAL_PARAMS] = {}
        for name, value in p_values.items():
            if name not in p_ext_param_defs:
                self.dic[helpers.LOCAL_PARAMS][name] = value

    def _serialize_ext_params(self, p_values, p_ext_param_defs):
        self.dic[helpers.EXT_PARAMS] = {}
        for name, value in p_values.items():
            if name in p_ext_param_defs:
                (src, par) = p_ext_param_defs[name]
                self.dic[helpers.EXT_PARAMS][name] = src + '.' + par


class PeerConfigSerializerCmd(PeerConfigSerializer):

    def __init__(self):
        self.args = []

    def _prepare(self, p_config):
        self.args = []

    def _save(self, p_file_obj):
        for a in self.args:
            p_file_obj.append(a)

    def _do_serialize_diff(self, p_base_config, p_config):
        sources, deps, params = self.difference(p_base_config, p_config)
        self._serialize_config_sources(p_config.config_sources)

        self._serialize_launch_deps(p_config.launch_deps)

        self._serialize_local_params(params, p_config.ext_param_defs)
        self._serialize_ext_params(params, p_config.ext_param_defs)

    def _serialize_config_sources(self, p_sources):
        for sname, peer_id in p_sources.items():
            self.args += [helpers.CS, sname, peer_id]

    def _serialize_launch_deps(self, p_deps):
        for sname, peer_id in p_deps.items():
            self.args += [helpers.LD, sname, peer_id]

    def _serialize_local_params(self, p_values, p_ext_param_defs):
        for name, value in p_values.items():
            if name not in p_ext_param_defs or value is not None:
                self.args += [helpers.LP, name, value]

    def _serialize_ext_params(self, p_values, p_ext_param_defs):
        for name, value in p_values.items():
            if name in p_ext_param_defs and value is None:
                (src, par) = p_ext_param_defs[name]
                self.args += [helpers.EP, name, src + '.' + par]
