# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

from obci.core.messages.config_messages import *  # noqa
from obci.core.messages.launcher_msg_types import *  # noqa
from obci.core.messages.launcher_common_types import *  # noqa
from obci.core.messages.psychopy import *  # noqa
from obci.core.messages.signal_saver import *  # noqa
from obci.core.messages.types import *  # noqa
from obci.core.messages.svarog import *  # noqa


def deserialize(msg: 'Tuple[bytes]'):
    from . import base
    return base.MessageMeta.deserialize(msg)
