# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""This module contains peers, which support virtual and real amplifiers."""
from . import random_amplifier_peer, lsl_amplifier_peer, openbci_amplifier_peer  # noqa
