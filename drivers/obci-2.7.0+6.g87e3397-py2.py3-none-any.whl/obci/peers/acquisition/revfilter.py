import logging
import os

import numpy
import scipy.signal

from obci.signal_processing import read_manager
from obci.signal_processing.signal import signal_exceptions
from obci.signal_processing.signal.signal_constants import SAMPLE_NUMPY_TYPES

__all__ = ('reverse_impedance_filter',)

# see also https://redmine.titanis.pl/issues/37893
# cpp_amplifiers/src/brainamp/BrainAmplifier.cpp
# cpp_amplifiers/src/brainamp/BrainAmplifier.h

logger = logging.getLogger(__name__)


class IIRFilter:
    def __init__(self, a, b):  # a,b - filter coefficients
        self.a = a
        self.b = b
        self.zi = scipy.signal.lfilter_zi(b, a)  # state (memory) of the filter

    def get(self, x):
        """
        Apply the filter. Remember/pass the filter internal state from call to call.
        :param x: numpy array
        :return: numpy array (len == len(x))
        """
        out, self.zi = scipy.signal.lfilter(self.b, self.a, x, zi=self.zi)
        return out


class CascadeFilter:
    def __init__(self, filters_def):
        self.filters = [IIRFilter(f['a'], f['b']) for f in filters_def]

    def get(self, x):
        out = x
        for f in self.filters:
            out = f.get(out)
        return out


def reverse_impedance_filter(fxml, fraw, filters):
    """
    Apply IIRFilters on .raw file backwards, used to cancel phase offset due to impedance filtering.
    :param fxml: .obci.xml filepath
    :param fraw: .obci.raw filepath
    :param filters: vector (size=numofchannels) of dicts (filter definitions {'a','b' filetparams})
    :return: None
    """
    mgr = read_manager.ReadManager(fxml, fraw, None)

    def samples_backwards():  # generator -> samples (numpy array of shape: (nchan, nsamples))
        nsamples = int(mgr.get_param('number_of_samples'))
        step = 10000
        while nsamples:  # read samples backwards, <step> samples at a time.
            step = min(step, nsamples)
            try:
                samples = mgr.get_samples(p_from=nsamples - step, p_len=step)
            except signal_exceptions.NoNextValue:
                logger.warning("Got NoNextValue exception, skipping.")
            else:
                yield (samples[:, ::-1])
            finally:
                nsamples -= step

    def filtered():  # filter samples
        fs = None
        for ss in samples_backwards():
            if fs is None:
                fs = [CascadeFilter(filters[i]) for i in range(len(ss))]
            out = numpy.empty_like(ss)
            for i in range(len(ss)):
                out[i] = fs[i].get(ss[i])
            yield out

    def reverse_save():
        writepos = os.stat(fraw).st_size
        frev = fraw + '.rev'
        with open(frev, 'wb') as f:
            for ss in filtered():
                bindata = ss[:, ::-1].astype(SAMPLE_NUMPY_TYPES[mgr.get_param('sample_type')],
                                             copy=False).T.tobytes(order='C')
                writepos -= len(bindata)
                f.seek(writepos)
                f.write(bindata)
        return frev

    frev = reverse_save()
    mgr = None
    os.replace(frev, fraw)
    return


if __name__ == "__main__":
    reverse_impedance_filter("test.xml", "test.raw", [[]] * 123)
