import struct
from typing import Optional, Union

import numpy as np

from obci.core import ObciException

__all__ = (
    'Impedance',
    'SamplePacket',
    'ArrayWithImpedance',
    'NoImpedanceLoaded',
    'NETWORK_FLOAT32',
)

NETWORK_FLOAT32 = np.dtype('float32').newbyteorder('>')


class Impedance:
    NETWORK_INT8 = np.dtype('int8')

    UNKNOWN = 0
    NOT_APPLICABLE = 1
    PRESENT = 2

    def __init__(self, ids: Union[list, np.array], data: Optional[Union[list, np.array]]):
        """
        Structure for representing impedance.

        If impedance is not supported by the driver, ids and data are initialized
        with empty lists.

        If driver supports impedance, then ids is non empty array with True/False values
        representing if data is available for each of the active channels.
        Then if impedance data of any of the active channels is available data array is
        initialized as 2-dimensional array with columns representing samples
        and rows representing channels.
        If none of the active channels has impedance available then data is initialized
        with empty list.

        Examples (tests) are in test/signal_processing/test_sample.packet.py

        :param ids: Numpy array of impedance flags for each active channel in packet
                    or empty array if device do not support impedance.
        :param data: Numpy array of impedance data for each channel on which it is available.
        """
        self._ids = np.asarray(ids, dtype=self.NETWORK_INT8)  # as many as channels impedance flags
        self._data = np.asarray(data, dtype=NETWORK_FLOAT32)
        self._channel_to_impedance_map = None
        self._matrix = None
        assert len(self._ids.shape) == 1, \
            'ids shape {} should be of length 1'.format(self._ids.shape)
        assert len(self._data.shape) == 2, \
            'data shape {} should be of length 2'.format(self._data.shape)
        assert self.impedance_channel_count == np.sum(self._ids == self.PRESENT), \
            'impedance channels count ({}) should be equal to number of ' \
            'impedance PRESENT flags count ({})'.format(
                self.impedance_channel_count, np.sum(self._ids == self.PRESENT))
        assert self._data.shape[1] == self.impedance_channel_count, \
            'data shape[1] ({}) should equal to channels with ' \
            'impedance count ({})'.format(
                self._data.shape[1], self.impedance_channel_count)

    @property
    def all_channels_data(self):
        if self._matrix is None:
            self._matrix = self._create_impedance_matrix()
        return self._matrix

    def _create_impedance_matrix(self):
        impedance = np.empty((self._data.shape[0], len(self._ids)))
        impedance[:] = np.nan
        impedance[:, self._ids == self.PRESENT] = self._data
        return impedance

    @classmethod
    def create_unknown(cls, channel_count, sample_count):
        return cls(ids=np.full(channel_count, Impedance.UNKNOWN, cls.NETWORK_INT8),
                   data=cls.create_empty_data(sample_count))

    @classmethod
    def create_empty_data(cls, sample_count):
        return np.empty((sample_count, 0), NETWORK_FLOAT32)

    def _prepare_channel_map(self):
        self._channel_to_impedance_map = {}
        mapped_channel = 0
        for nr, i in enumerate(self._ids):
            if i == self.PRESENT:
                self._channel_to_impedance_map[nr] = mapped_channel
                mapped_channel += 1

    def for_channel(self, channel_number: int) -> Union[np.array, object]:
        """Get impedance for channel."""
        if self._channel_to_impedance_map is None:
            self._prepare_channel_map()
        flag = self._ids[channel_number]
        if flag == self.PRESENT:
            return self._data[:, self._channel_to_impedance_map[channel_number]]
        else:
            return flag

    def to_bytes(self):
        return self._ids.tobytes() + self._data.tobytes()

    @classmethod
    def from_bytes(cls, data, channel_count, sample_count):
        if len(data) == 0:
            return cls.create_unknown(channel_count, sample_count)
        ids, position = _from_buffer(
            data, dtype=cls.NETWORK_INT8, count=channel_count
        )
        impedance_channel_count = np.sum(ids == cls.PRESENT)
        data, position = _from_buffer(
            data,
            dtype=NETWORK_FLOAT32,
            count=impedance_channel_count * sample_count,
            offset=position
        )
        data = data.reshape(sample_count, impedance_channel_count)
        return cls(ids=ids, data=data)

    @property
    def data(self):
        return self._data

    @property
    def flags(self):
        return self._ids

    @property
    def channel_count(self):
        return len(self._ids)

    @property
    def sample_count(self):
        return self._data.shape[0]

    @property
    def impedance_channel_count(self):
        return self._data.shape[1]

    def __eq__(self, other):
        ids_are_the_same = self._ids == other._ids
        if isinstance(ids_are_the_same, type(np.array)):
            ids_are_the_same = ids_are_the_same.all()

        data_is_the_same = self._data == other._data
        if isinstance(data_is_the_same, type(np.array)):
            data_is_the_same = data_is_the_same.all()

        return ids_are_the_same and data_is_the_same


class SamplePacket:
    """A packet of samples."""

    HEADER_FORMAT = '>HH'
    HEADER_SIZE = 4
    NETWORK_FLOAT32 = NETWORK_FLOAT32
    NETWORK_FLOAT64 = np.dtype('float64').newbyteorder('>')

    def __init__(self, samples: np.ndarray, ts: np.ndarray, impedance: Optional[Impedance] = None):
        """
        Initialize packet of samples.

        :param samples: numpy 2D array of size (sample_count, channel_count)
        :param ts: numpy 1D array of size sample_count
        """
        if len(samples.shape) != 2 or len(ts.shape) != 1 or samples.shape[0] != ts.shape[0]:
            raise Exception("invalid data dimensions: samples~{} ts~{}".format(samples.shape, ts.shape))
        self._samples = samples
        self._ts = ts
        self._impedance = impedance if impedance is not None else Impedance.create_unknown(self.channel_count,
                                                                                           self.sample_count)

    @property
    def samples(self):
        """Return samples."""
        return self._samples

    @property
    def ts(self):
        """Return timestamps."""
        return self._ts

    @property
    def sample_count(self):
        """Return sample count."""
        return self._samples.shape[0]

    @property
    def channel_count(self):
        """Return channel count."""
        return self._samples.shape[1]

    def __eq__(self, other):
        """Equality operator."""
        if (self.samples == other.samples).all() and (self.ts == other.ts).all():
            return True
        else:
            return False

    def to_bytes(self) -> bytes:
        """Serialize SignalMessage data to ``bytes``."""
        sample_count, channel_count = self.samples.shape
        times64 = self.ts.astype(self.NETWORK_FLOAT64)
        samples32 = self.samples.astype(self.NETWORK_FLOAT32)
        binary = struct.pack(self.HEADER_FORMAT, sample_count, channel_count)
        binary += times64.tobytes()
        binary += samples32.tobytes()
        binary += self._impedance.to_bytes()
        return binary

    @classmethod
    def from_bytes(cls, data: bytes):
        """
        Deserialize message data from second part of multipart message.

        Here for maximum performance this function returns not a dict for __init__ but ready to use SamplePacket.
        """
        try:
            sample_count, channel_count = struct.unpack(cls.HEADER_FORMAT, data[:cls.HEADER_SIZE])

            times64, position = _from_buffer(
                data,
                dtype=cls.NETWORK_FLOAT64,
                offset=cls.HEADER_SIZE,
                count=sample_count
            )
            samples32, position = _from_buffer(
                data,
                dtype=cls.NETWORK_FLOAT32,
                offset=position,
                count=sample_count * channel_count,
            )
            samples32 = samples32.reshape((sample_count, channel_count))
            impedance = Impedance.from_bytes(data[position:], channel_count, sample_count)
            return cls(ts=times64, samples=samples32, impedance=impedance)
        except Exception as ex:
            raise ObciException("Invalid signal message") from ex

    @property
    def impedance(self) -> Impedance:
        return self._impedance


class NoImpedanceLoaded(AttributeError):
    pass


class ArrayWithImpedance(np.ndarray):
    def __new__(mcls, input_array, impedance: Impedance = None):
        obj = np.asanyarray(input_array).view(mcls)
        obj._impedance_obj = impedance
        return obj

    @property
    def impedance(self):
        if self._impedance_obj is None:
            raise NoImpedanceLoaded
        else:
            # ReadManager is returning samples in the shape of (CHANNEL_COUNT X SAMPLE_COUNT)
            # Impedance should be returned in similar shape
            return self._impedance_obj.all_channels_data.T

    @property
    def impedance_flags(self):
        if self._impedance_obj is None:
            raise NoImpedanceLoaded
        else:
            return self._impedance_obj.flags


def _from_buffer(buffer, dtype, count=-1, offset=0):
    array = np.frombuffer(buffer, dtype, count, offset)
    return array, offset + array.nbytes
