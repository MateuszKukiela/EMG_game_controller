# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""
Module defines single :class: 'DataAsciiWriteProxy'.

Author:
    Mateusz Kruszyński <mateusz.kruszynski@gmail.com>
"""
from .data_generic_write_proxy import DataGenericWriteProxy, SamplePacket


class DataAsciiWriteProxy(DataGenericWriteProxy):
    """Subclass write data in ASCII format to file."""

    def __init__(self, p_file_path, p_append_ts=False):
        """Open p_file_path file for writing."""
        self.append_timestamps = p_append_ts
        super().__init__(p_file_path, 'wt')

    def data_received(self, packet: SamplePacket):
        """
        Method gets and saves next sample of signal.

        :param packet: 'SamplePacket'
        """
        output = list(self._extract_data(packet))
        self._write_file(str(output) + '\n')
        self._number_of_samples += 1

    def _extract_data(self, packet):
        samples = packet.samples.tolist()
        if self.append_timestamps:
            timestamps = packet.ts.tolist()
            for sample, timestamp in zip(samples, timestamps):
                yield sample + [timestamp]
        else:
            yield from samples
