# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""Module to compute posturographic measures.

(most after Prieto T., "Measures of Postural Steadiness:
Differences Between Healthy Young and Elderly Adults", IEEE Transactions of biomedical engineering,
vol. 43, no. 9, 1996)

- max_sway_AP_MP()
- COP_path()
- RMS_AP_ML()
- confidence_ellipse_area()
- mean_velocity()
- reaction_time()
- triangles_area()
- mean_angle()
- mean_COP_distance()
"""
from .raw_analysis import max_sway_AP_ML, RMS_AP_ML, confidence_ellipse_area, plot_COP, COP_path, mean_velocity, \
    mean_COP_sway_AP_ML, get_percentages_values
import numpy as np


def wii_max_sway_AP_MP(x, y):
    """Return maximal sway values for medio-lateral and anterio-posterior directions.

    Input:
    x 				-- array -- samples from x channel
    y 				-- array -- samples from y channel
    Output:
    max_sway 	--	float
    max_AP   	--  float
    max_ML  	--  float
    """
    return max_sway_AP_ML(np.vstack((x, y)))


def wii_COP_path(wbb_mgr, x, y, plot=False):
    """Return total length of the COP path.

    Input:
    WBBReadManager 	-- WBBReadManager object
    x 				-- array -- samples from x channel
    y 				-- array -- samples from y channel
    plot 			-- bool  -- optional
    """
    if plot:
        fs = float(wbb_mgr.get_param('sampling_frequency'))
        plot_COP(np.vstack((x, y)), fs)
    return COP_path(np.vstack((x, y)))


def wii_RMS_AP_ML(x, y):
    """Return Root Mean Square (RMS) values in medio-lateral and anterio-posterior directions."""
    return RMS_AP_ML(np.vstack((x, y)))


def wii_confidence_ellipse_area(x, y):
    """Return area of the 95 perc. confidence ellipse."""
    return confidence_ellipse_area(np.vstack((x, y)))


def wii_mean_velocity(wbb_mgr, x, y):
    """Return average velocity of the COP, in ML and AP directions.

    Input:
    WBBReadManager 	-- WBBReadManager object
    x 				-- array -- samples from x channel
    y 				-- array -- samples from y channel
    """
    fs = float(wbb_mgr.get_param('sampling_frequency'))
    return mean_velocity(np.vstack((x, y)), fs)


def wii_mean_COP_sway_AP_ML(x, y):
    """Return mean value of COP sway from the center point (0,0).

    Input:
    x 				-- array -- samples from x channel
    y 				-- array -- samples from y channel
    """
    return mean_COP_sway_AP_ML(np.vstack((x, y)))


def wii_get_percentages_values(wbb_mgr, x, y, plot=False):
    """
    Return percentages of being on each of four parts of board.

    Input:
    WBBReadManager 	-- WBBReadManager object
    x 				-- array -- samples from x channel
    y 				-- array -- samples from y channel
    plot 			-- bool  -- optional

    Output:
        top_right 		-- float
        top_left		-- float
        bottom_right	-- float
        bottom_left		-- float
    """
    fs = float(wbb_mgr.get_param('sampling_frequency'))
    return get_percentages_values(np.vstack((x, y)), fs, plot=plot)
