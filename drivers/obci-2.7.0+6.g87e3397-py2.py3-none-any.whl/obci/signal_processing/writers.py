import copy
import os
import os.path

from . import logging
from .signal import data_write_proxy
from .signal import info_file_proxy
from .signal.containers import Impedance
from .tags import tags_file_writer

from obci.peers.acquisition.revfilter import reverse_impedance_filter


__all__ = ('SignalWriter', 'ImpedanceFlagsAlreadySet',
           'FirstSampleTimestampAlreadySet')


LOG = logging.get_logger(__name__)


class FirstSampleTimestampAlreadySet(RuntimeError):
    pass


class ImpedanceFlagsAlreadySet(RuntimeError):
    pass


class SignalWriter:
    DATA_FILE_EXTENSION = ".obci.raw"
    INFO_FILE_EXTENSION = ".obci.xml"
    TAG_FILE_EXTENSION = ".obci.tag"

    def __init__(self, *, save_file_path: str, save_file_name: str,
                 append_timestamps: bool, use_own_buffer: bool,
                 save_tags: bool, save_impedance: bool, sample_type,
                 channels_info, data_file_extension: str=None,
                 info_file_extension: str=None, tag_file_extension: str=None):
        self._first_sample_timestamp = None
        self._impedance_flags = None
        self._number_of_samples = 0
        self._append_timestamps = append_timestamps
        self._sample_type = sample_type
        self._save_tags = save_tags
        self._save_impedance = save_impedance
        self._channels_info = channels_info
        if not os.access(save_file_path, os.F_OK):
            os.makedirs(save_file_path, exist_ok=True)

        self._file_path = os.path.normpath(os.path.join(
            save_file_path,
            save_file_name + (data_file_extension or self.DATA_FILE_EXTENSION)
        ))
        self._data_proxy = data_write_proxy.get_proxy(
            self._file_path, append_timestamps, use_own_buffer, sample_type, save_impedance)

        self._file_path_info = os.path.expanduser(os.path.normpath(os.path.join(
            save_file_path,
            save_file_name + (info_file_extension or self.INFO_FILE_EXTENSION)
        )))
        self._info_proxy = info_file_proxy.InfoFileWriteProxy(self._file_path_info)

        if save_tags:
            self._file_path_tag = os.path.expanduser(os.path.normpath(os.path.join(
                save_file_path,
                save_file_name + (tag_file_extension or self.TAG_FILE_EXTENSION)
            )))
            self._tags_proxy = tags_file_writer.TagsFileWriter(self._file_path_tag)

    def write(self, sample_packet, samples_count):
        self._number_of_samples += samples_count
        self._data_proxy.data_received(sample_packet)

    def add_tag(self, tag: dict):
        self._tags_proxy.tag_received(tag)

    def finish_saving(self, *, active_channels, sampling_rate,
                      channel_names, channel_gains, channel_offsets):
        self._data_proxy.finish_saving()
        self._finish_saving_info(
            active_channels=active_channels,
            sampling_rate=sampling_rate,
            channel_names=channel_names,
            channel_gains=channel_gains,
            channel_offsets=channel_offsets,
        )

        if self._save_tags:
            self._finish_saving_tag()
        if self._channels_info:
            try:  # https://redmine.titanis.pl/issues/38821
                filters = [ch.get('filters', []) for ch in self._channels_info]
                optional_tss_channel = [[]]
                filters += optional_tss_channel
                reverse_impedance_filter(self._file_path_info, self._file_path,
                                         filters)
            except Exception:
                import traceback
                traceback.print_exc()

    def _finish_saving_info(self, *, active_channels, sampling_rate,
                            channel_names, channel_gains, channel_offsets):
        """Create xml manifest file."""
        signal_params = {
            'number_of_channels': len(active_channels),
            'sampling_frequency': sampling_rate,
            'sample_type': self._sample_type,
            'channels_numbers': copy.copy(active_channels),
            'channels_names': copy.copy(channel_names),
            'channels_gains': copy.copy(channel_gains),
            'channels_offsets': copy.copy(channel_offsets),
            'number_of_samples': self._number_of_samples,
            'file': str(self._file_path),
            'first_sample_timestamp': repr(self.first_sample_timestamp)
        }
        if self._append_timestamps:
            signal_params['number_of_channels'] += 1
            signal_params["channels_numbers"].append("1000")

            # Add name to special channel
            signal_params["channels_names"].append("TSS")

            # Add gain to special channel
            signal_params["channels_gains"].append(1.0)

            # Add offset to special channel
            signal_params["channels_offsets"].append(0.0)

        if self._save_impedance:
            impedance_channels_names = [
                'Imp_{name}'.format(name=name)
                for name, flag in zip(channel_names, self._impedance_flags)
                if flag == Impedance.PRESENT
            ]
            signal_params['channels_names'] += impedance_channels_names
            signal_params['channels_gains'] += [1] * len(impedance_channels_names)
            signal_params['channels_offsets'] += [0] * len(impedance_channels_names)
            channel_flags = self._impedance_flags.tolist()
            if self._append_timestamps:
                channel_flags += [Impedance.NOT_APPLICABLE]
            signal_params['channels_flags'] = channel_flags
            signal_params['number_of_channels'] += len(impedance_channels_names)

        msg = "Finished saving info with values:\n"
        for key, val in signal_params.items():
            msg = ''.join([msg, key, " : ", str(val), "\n"])
        LOG.info(msg)

        self._info_proxy.finish_saving(signal_params)

    def _finish_saving_tag(self):
        """Save all tags to xml file.

        Before saving update tag's .position field so that
        it is relative to timestamp of a first sample stored
        by signal saver (p_first_sample_ts).
        """
        LOG.info("Finish saving with first sample ts: " + repr(self.first_sample_timestamp))
        file_path = self._tags_proxy.finish_saving(self.first_sample_timestamp)
        LOG.info("Tags file saved to: " + file_path)
        return file_path

    @property
    def first_sample_timestamp(self):
        return self._first_sample_timestamp

    @first_sample_timestamp.setter
    def first_sample_timestamp(self, value):
        if self._first_sample_timestamp is None:
            self._first_sample_timestamp = value
            self._data_proxy.set_first_sample_timestamp(value)
        else:
            raise FirstSampleTimestampAlreadySet

    @property
    def impedance_flags(self):
        return self._first_sample_timestamp

    @impedance_flags.setter
    def impedance_flags(self, value):
        if self._impedance_flags is None:
            self._impedance_flags = value
        else:
            raise ImpedanceFlagsAlreadySet
