import numpy as np

from obci.signal_processing.buffers import ring_buffer as rbn
from obci.signal_processing.signal.data_generic_write_proxy import (
    Impedance, SamplePacket
)
from obci.utils.properties import property_no_longer_public


class _ImpedanceForAutoBuffers(Impedance):
    def for_channel(self, channel_number: int):
        """Return impedance for channel if present or None."""
        impedance = super().for_channel(channel_number)
        if isinstance(impedance, np.ndarray):
            return impedance
        else:
            return None

    def __repr__(self):
        return str(self._data)


class AutoBuffer:
    whole_buf_len = property_no_longer_public(public_name='whole_buf_len', private_name='_size')
    is_full = property_no_longer_public(public_name='is_full', private_name='_is_full')
    count = property_no_longer_public(public_name='count', private_name='_number_of_samples_in_buffer')
    buffer = property_no_longer_public(public_name='buffer', private_name='_sample_buffer')
    ret_buf_len = property_no_longer_public(public_name='ret_buf_len', private_name='_number_of_samples_to_return')
    ret_func = property_no_longer_public(public_name='ret_func', private_name='_return_sample_callback')

    def __init__(self, buffer_size: int, samples_count: int,
                 num_of_channels: int, ret_func: callable, copy_on_ret: bool,
                 return_impedance: bool = False):

        assert buffer_size > 0
        assert samples_count > 0
        assert num_of_channels > 0
        assert isinstance(return_impedance, bool)

        self._number_of_samples_to_return = samples_count
        self._number_of_channels = num_of_channels
        self._return_sample_callback = ret_func
        self._copy_data_on_get = copy_on_ret
        self._return_impedance = return_impedance

        self._size = buffer_size
        self._sample_buffer = rbn.RingBuffer(
            size=buffer_size,
            number_of_channels=num_of_channels,
            copy_on_ret=copy_on_ret,
        )
        self._number_of_samples_in_buffer = 0

        self._impedance_buffer = None
        self._impedance_channels_flags = ()

    @property
    def _is_full(self):
        return self._number_of_samples_in_buffer == self._size

    def clear(self):
        self._number_of_samples_in_buffer = 0
        self._sample_buffer.clear()
        self._impedance_buffer = None
        self._impedance_channels_flags = ()

    def handle_sample_packet(self, sample_packet: SamplePacket):
        if self._return_impedance:
            if self._impedance_buffer is None:
                self._initialize_impedance_buffer(sample_packet)
            for impedance in sample_packet.impedance.data:
                self._add_impedance_to_buffer(impedance)
        self.add_samples_to_buffer(sample_packet.samples.T)

    def _initialize_impedance_buffer(self, sample_packet: SamplePacket):
        self._impedance_channels_flags = tuple(sample_packet.impedance.flags)
        self._impedance_buffer = rbn.RingBuffer(
            size=self._size,
            number_of_channels=sample_packet.impedance.impedance_channel_count,
            copy_on_ret=self._copy_data_on_get,
        )

    def _add_impedance_to_buffer(self, impedance: np.ndarray):
        self._impedance_buffer.add(impedance)

    def add_samples_to_buffer(self, samples: np.ndarray):
        self._sample_buffer.add(samples)
        self._number_of_samples_in_buffer = min(self._size, self._number_of_samples_in_buffer + samples.shape[1])

    def add_sample_to_buffer(self, s: np.ndarray):
        self.add_samples_to_buffer(np.asanyarray(s)[:, np.newaxis])

    def _call_return_sample_callback(self, start, length, call_back_args):
        samples = self._sample_buffer.get(start, length)
        if self._return_impedance:
            impedance = _ImpedanceForAutoBuffers(
                ids=self._impedance_channels_flags,
                data=self._impedance_buffer.get(
                    start, length
                ).T
            )
            self._return_sample_callback(*call_back_args, samples, impedance)
        else:
            self._return_sample_callback(*call_back_args, samples)
