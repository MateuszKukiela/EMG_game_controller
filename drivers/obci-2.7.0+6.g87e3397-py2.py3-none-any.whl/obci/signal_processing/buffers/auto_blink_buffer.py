# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""Module provides classes representing single blink and blink buffers."""
import collections

import numpy as np

from obci.signal_processing.buffers import base as buffers
from obci.signal_processing.buffers import ring_buffer as rbn
from obci.utils.properties import property_no_longer_public


class Blink:
    """:class:'Blink' initializes packet of a blink."""

    def __init__(self, timestamp, index):
        """Initialize packet of a blink."""
        self.timestamp = timestamp
        self.index = index


class BlinkEntry(object):
    """Class representing single blink."""

    def __init__(self, blink: Blink, blink_count: int, blink_pos: int) -> None:
        """
        Blink variable as a representation of the stimulus.

        :param blink: variable Blink (object with one field named timestamp)
        :param blink_count: index of the stimulus
        :param blink_pos: position of the stimulus in relation to the indexes of the samples in the buffer.
        """
        self.blink = blink
        self.count = blink_count
        self.position = blink_pos


class AutoBlinkBuffer(buffers.AutoBuffer):
    """
    Class representing buffer which returns predefined epochs of signal around some blink event.

    Ex. to use in event related potential paradigms.
    """

    sampling = property_no_longer_public(public_name='sampling', private_name='_sampling_frequency')
    times = property_no_longer_public(public_name='times', private_name='_time_buffer')

    def __init__(self, from_blink, samples_count, num_of_channels, sampling, ret_func, copy_on_ret,
                 return_impedance: bool = False):
        """
        After occurrence of the blink and getting a sufficient number of samples calls ret_func(blink, d).

        Blink is a Blink variable and d is a corresponding numpy array with
        <samples_count> samples from <num_of_channels> channels.

        :param from_blink: blink from which start collecting samples
        :param samples_count: number of samples to return
        :param num_of_channels: number of channels to return
        :param sampling: sampling frequency
        :param ret_func: function to call when return. Takes returned samples.
        :param copy_on_ret: if true make deep copy of the buffer while processing
        """
        assert (samples_count > 0)
        assert (num_of_channels > 0)
        assert isinstance(return_impedance, bool)

        buffer_size = (samples_count + abs(from_blink)) * 2
        super().__init__(buffer_size=buffer_size, samples_count=samples_count,
                         num_of_channels=num_of_channels, ret_func=ret_func,
                         copy_on_ret=copy_on_ret,
                         return_impedance=return_impedance)

        self.blink_from = from_blink
        self._sampling_frequency = sampling
        self.curr_blink = None
        self.curr_blink_ts = None
        self.blinks_count = 0
        self.blinks = collections.deque()

        self._time_buffer = rbn.RingBuffer(
            size=self._size,
            number_of_channels=1,
            copy_on_ret=copy_on_ret,
        )

    def clear(self):
        """Clear buffer."""
        super().clear()
        self._time_buffer.clear()
        self._clear_blinks()

    def _clear_blinks(self):
        self.blinks_count = 0
        self.blinks.clear()

    def handle_blink(self, blink: Blink) -> None:
        """
        Method which assigns index and position to the Blink and queues this Blink.

        :param blink: Blink (object with one field named timestamp)
        :return:
        """
        if not self._is_full:
            print("AutoBlinkBuffer - Got blink before buffer is full. Ignore!")
            return
        blink_ts = blink.timestamp + (self.blink_from / self._sampling_frequency)
        blink_pos = self._get_times_index(blink.timestamp)
        no_data_present = blink_pos >= self._number_of_samples_in_buffer - 1
        if blink_pos < 0:
            return
        elif no_data_present:
            blink_count = self._number_of_samples_to_return + int(
                self._sampling_frequency * (blink_ts - self._get_times_last()))
            blink_pos = self._size - self._number_of_samples_to_return
        else:
            # gdzies w srodku
            blink_count = self._number_of_samples_to_return - (self._size - blink_pos)
            if blink_count < 0:
                blink_count = 0
            blink_pos -= blink_count

        if not len(self.blinks) == 0:
            blink_count -= self.blinks_count

        b = BlinkEntry(blink, blink_count, blink_pos)
        self.blinks.append(b)
        self.blinks_count += blink_count

    def handle_sample_packet(self, sample_packet):
        """
        Method handles signal sample packets in a manner consistent with AutoBlinkBuffer.

        :param sample_packet: signal as a SamplePacket class.
        :return: None
        """
        self._time_buffer.add(sample_packet.ts[np.newaxis, :])
        super().handle_sample_packet(sample_packet)

    def add_sample_to_buffer(self, s):
        # blinks samples have to be processed one by one
        super().add_samples_to_buffer(np.asanyarray(s)[:, np.newaxis])

        if self._is_full and self.blinks:
            current_blink_entry = self.blinks[0]
            current_blink_entry.count -= 1
            self.blinks_count -= 1
            if current_blink_entry.count <= 0:
                current_blink_entry = self.blinks.popleft()
                self._call_return_sample_callback(
                    start=current_blink_entry.position,
                    length=self._number_of_samples_to_return,
                    call_back_args=(current_blink_entry.blink,)
                )

    def add_samples_to_buffer(self, samples: np.ndarray):
        # blinks samples have to be processed one by one
        for sample in samples.T:
            self.add_sample_to_buffer(sample)

    def _get_times_index(self, value):
        timestamps = self._time_buffer[:][0]
        return timestamps.searchsorted(value, side='right') - 1

    def _get_times_last(self):
        return self._time_buffer[-1]
