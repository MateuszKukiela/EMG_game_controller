# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""Module provides single class representing sample packet buffer."""
import numpy as np

from obci.signal_processing.buffers import base as buffers
from obci.utils.properties import property_no_longer_public


class AutoRingBuffer(buffers.AutoBuffer):
    """Class representing sample packet buffer. When full calls ret_func."""

    every = property_no_longer_public(public_name='every', private_name='_number_of_samples_to_skip')

    def __init__(self, from_sample, samples_count, every, num_of_channels, ret_func, copy_on_ret,
                 return_impedance: bool = False):
        """
        When full, calls ret_func(d), where d is numpy array with <samples_count>samples from <num_of_channels>channels.

        Skips samples before next ret_func call.

        :param from_sample: size of the buffer
        :param samples_count: number of samples to return
        :param every: interval (number of samples to skip) before next return
        :param num_of_channels: number of channels in the returned signal
        :param ret_func: function to call when return. Takes returned samples.
        :param copy_on_ret: if true make deep copy of the buffer while processing
        """
        assert (from_sample > 0)
        assert (every > 0)

        buffer_size = from_sample
        super().__init__(buffer_size=buffer_size, samples_count=samples_count,
                         num_of_channels=num_of_channels, ret_func=ret_func,
                         copy_on_ret=copy_on_ret,
                         return_impedance=return_impedance)

        self._number_of_samples_to_skip = every
        self._samples_to_skip_counter = 0

    def clear(self):
        """Clear buffer."""
        super().clear()
        self._samples_to_skip_counter = 0

    def add_samples_to_buffer(self, samples: np.ndarray):
        if self._is_full:
            next_possible_callback = self._number_of_samples_to_skip - self._samples_to_skip_counter
        else:
            next_possible_callback = self._size - self._number_of_samples_in_buffer
        if samples.shape[1] > next_possible_callback:
            self.add_samples_to_buffer(samples[:, :next_possible_callback])
            self.add_samples_to_buffer(samples[:, next_possible_callback:])
        elif samples.shape[1] != 0:
            super(AutoRingBuffer, self).add_samples_to_buffer(samples)
            self._samples_to_skip_counter += samples.shape[1]
            self._samples_to_skip_counter %= self._number_of_samples_to_skip
            if self._is_full and self._samples_to_skip_counter == 0:
                self._call_return_sample_callback(
                    start=0,
                    length=self._number_of_samples_to_return,
                    call_back_args=(),
                )
                self._samples_to_skip_counter = 0
