# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""Module provides single class representing buffer."""
import copy

import numpy as np

from obci.utils.properties import property_no_longer_public


class RingSampleBuffer:
    """Subclass 'RingBufferBase' representing  buffer."""

    index = property_no_longer_public(public_name='index', private_name='_position_of_sample_in_buffer')
    copy_on_ret = property_no_longer_public(public_name='copy_on_ret', private_name='_copy_data_on_get')
    number_of_channels = property_no_longer_public(public_name='number_of_channels', private_name='_number_of_channels')
    size = property_no_longer_public(public_name='size', private_name='_size')
    buffer = property_no_longer_public(public_name='buffer', private_name='_buffer')

    def __init__(self, size: int, number_of_channels: int, copy_on_ret: bool):
        """Initialize buffer."""
        assert size > 0
        self._size = int(size)
        self._is_full = False
        self._position_of_sample_in_buffer = 0
        self._number_of_channels = int(number_of_channels)
        self._copy_data_on_get = bool(copy_on_ret)
        self._buffer = np.zeros(
            (self._number_of_channels, self._size), dtype='float'
        )

    def clear(self):
        """Clear buffer."""
        self._is_full = False
        self._position_of_sample_in_buffer = 0
        self._buffer = np.zeros(
            (self._number_of_channels, self._size), dtype='float'
        )

    def add(self, s):
        """Add sample or sampls to buffer."""
        s = np.asanyarray(s)
        if len(s.shape) == 1:
            s = s[:, np.newaxis]
        elif s.shape[1] == 0:
            return
        if self._position_of_sample_in_buffer + s.shape[1] > self._size:
            split = self._size - self._position_of_sample_in_buffer
            self.add(s[:, :split])
            self.add(s[:, split:])
            return

        self._buffer[:, self._position_of_sample_in_buffer:self._position_of_sample_in_buffer + s.shape[1]] = s
        if not self._is_full:
            self._is_full = self._position_of_sample_in_buffer + s.shape[1] >= self._size
        self._position_of_sample_in_buffer = (self._position_of_sample_in_buffer + s.shape[1]) % self._size

    def get(self, start, length):
        """Get samples from buffer (start, start + length)."""
        assert 0 <= start and 0 <= length <= self._size
        if length == 0:
            return np.empty((0, 0))

        offset = self._position_of_sample_in_buffer if self._is_full else 0
        head = (offset + start) % self._size
        tail = (offset + start + length) % self._size

        if head < tail:
            data = self._buffer[:, head:tail]
        else:
            data = np.concatenate(
                (self._buffer[:, head:], self._buffer[:, :tail]),
                axis=1
            )

        if self._copy_data_on_get:
            return copy.deepcopy(data)
        else:
            return data

    def __getitem__(self, s):
        current_size = self._size if self._is_full else self._position_of_sample_in_buffer
        if isinstance(s, slice):
            assert s.step is None, "Not supported"
            start, stop, _ = s.indices(current_size)
            return self.get(start, stop - start)
        elif isinstance(s, int):
            if s < 0:
                s += current_size
            if s > self._size:
                raise IndexError
            return self.get(s, 1)[:, 0]
        else:
            raise TypeError


# backward compatibility
RingBuffer = RingSampleBuffer
