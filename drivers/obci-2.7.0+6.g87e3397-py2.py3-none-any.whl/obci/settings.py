# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved
import configparser
import importlib
import os
import socket


class OBCISettings:
    INSTALL_DIR = os.path.dirname(__file__)
    ENV_VAR = 'OBCI_SETTINGS'
    LOGGING = {
        'formatters': {
            'console': {
                'format': "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            },

        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'console',
                'level': 'INFO',
            },
        },
        'loggers': {
            'peer': {
                'level': 'INFO'
            },
            'launcher': {
                'level': 'INFO'
            }
        },
        'root': {
            'level': 'DEBUG',
            'handlers': ['console'],
        },
        'disable_existing_loggers': False
    }

    def __init__(self, settings_file):
        self.settings_file = os.path.expanduser(settings_file)
        self._parser = None
        self._extensions = None

    @property
    def parser(self):
        if self._parser is None:
            self._parser = self._load_parser()
            self._parser.read([self.settings_file])
        return self._parser

    def _load_parser(self):
        parser = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
        parser.read_dict({
            'dirs': {
                'home': os.path.dirname(self.settings_file),
                'sandbox': "${home}/sandbox",
                'scenario': "${home}/scenarios",
                'log': "${home}/logs",
                'search_paths': self.INSTALL_DIR
            },
            'server': {
                'port': 54564,
                'pub_port': 34234,
                'rep_port': 12012,
            },
            'broker': {
                'port_range': "30000,60000",
                'peer_log_level': 'debug',
                'addresses': '0.0.0.0:31889',
            },
            'extensions': {
                'import_paths': '\n'.join([
                    'obci.peers.drivers.amplifiers',
                ])
            }
        })
        return parser

    def _path(self, section, var):
        return os.path.normpath(os.path.expanduser(self.parser.get(section, var)))

    @property
    def sandbox_dir(self):
        return self._path('dirs', 'sandbox')

    @property
    def scenario_dir(self):
        return self._path('dirs', 'scenario')

    @property
    def log_dir(self):
        return self._path('dirs', 'log')

    @property
    def home_dir(self):
        return self._path('dirs', 'home')

    @property
    def server_port(self):
        return self.parser.getint('server', 'port')

    @property
    def broker_port_range(self):
        return [int(p) for p in self.parser.get('broker', 'port_range').split(',')]

    @property
    def broker_addresses(self):
        addrs = os.environ.get('BROKER_ADDRESSES', self.parser.get('broker', 'addresses')).split(',')
        return [(addr.split(':')[0], int(addr.split(':')[1])) for addr in addrs]

    @property
    def broker_address(self):
        first = self.broker_addresses[0]
        return "%s:%d" % (socket.gethostbyname(first[0]), first[1])

    @property
    def search_paths(self):
        return self.parser.get('dirs', 'search_paths').split(';')

    @property
    def rep_port(self):
        return self.parser.getint('server', 'rep_port')

    @property
    def pub_port(self):
        return self.parser.getint('server', 'pub_port')

    @property
    def logging_config(self):
        try:
            import obci_logging_config
            logging_config = obci_logging_config.LOGGING
            logging_config['file'] = obci_logging_config.__file__
            return logging_config
        except ImportError:
            return self.LOGGING

    @property
    def module_path(self):
        return os.environ.get(self.ENV_VAR, 'obci.settings')

    def load_extensions(self):
        if self._extensions is None:
            import_paths = filter(None, [p.strip() for p in self.parser.get('extensions', 'import_paths').split('\n')])
            self._extensions = [importlib.import_module(name) for name in import_paths]


settings_class = OBCISettings
